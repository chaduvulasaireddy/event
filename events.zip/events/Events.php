<!DOCTYPE html>
<html>
<head>
<style>
    table,th ,td{
        border: 1px solid black;
    }
</style>
<title>content</title>
</head>
<body>
<h2>EVENTS DETAILS</h2>
<table>
<tr><td>Available Events Are:</td>
    <td></td>
</tr>
 <tr><td>CULTURAL EVENTS:SINGING,DANCING,INSTRUMENT PLAYING,MAGIC SHOW,DRAMA,RAMP WALK,FLASH MOB</td>
    <td></td>
</tr>
</tr>
 <tr><td></td>
    <td></td>
</tr>
</tr>
 <tr><td>TECHNICAL EVENTS:QUIZ,FUN GAMES,PROJECT EXPO,DEBATE,ARTS</td>
    <td></td>
</tr>
</tr>
</table>
</body>
</html>

