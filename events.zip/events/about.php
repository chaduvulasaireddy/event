<!DOCTYPE html>
<html>
<head>
<style>
    table,th ,td{
        border: 1px solid black;
    }
</style>
<title>content</title>
</head>
<body>
<h2>ADMIN DETAILS</h2>
<p>Event management system is used to manage all the activity related to event.It deals with all
the events that are conducted in a particular organisation or university. It is a platform that enables
you to register yourself for a particular group of tasks of an event.It gives you a detailed view of the
events that are held and going to be held in a university.
In this platform any student or a staff memeber on an administration official can access the
pages and can register or can get a glance of the events happening around them in the college. This
system helps the event management company to manage their paper work online and they can also
retrieve report of last event they have completed.</p>
<table>
<tr><td>Name:vaishnavi</td>
    <td></td>
</tr>
 <tr><td>Email id:o162005@rguktong.ac.in</td>
    <td></td>
</tr>
</tr>
 <tr><td>address:IIIT ONGOLE</td>
    <td></td>
</tr>
</tr>
 <tr><td>contact:6301751981</td>
    <td></td>
</tr>
</tr>
</table>
</body>
</html>

