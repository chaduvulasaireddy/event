<!DOCTYPE html>
<html>
<title>ADD EVENT</title>
<head>
<head>
<link rel="stylesheet" href="Project.css">
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<style type=text/css>
	@import "https://use.fontawesome.com/releases/v5.5.0/css/all.css";
</style>
</head>
<form action="login.php" method="post">
<table>
<tr>
	<td><i class="fas fa-user-circle"></i>Add Event:</td>
	<td><input type="text" name="event_name" placeholder="Enter your name"  pattern="[a-zA-Z]+" required/>
<tr>
	<td colspan=2><input type="submit" class="bt" name="signin" value="addevent"/></td>
</tr>
</tr></table>
<?php
	$user= 'root';
	$pwd='';
	$db='Project';
	$connect= new mysqli('localhost',$user,$pwd,$db);
$eventname=$_POST["event_name"];





$sql= "select * from add_event";
$result= $connect->query($sql);

$flag=0;

if($result->num_rows>0)
{
	while($rows=$result->fetch_assoc())
	{
		if($name==$rows['event_name'])
		{
			$flag=1;
			echo "successful";
			
			break;
		}
	}
		if($flag==0){
			$newrow="insert into project_register values ('$eventname')";
			if ($connect->query($newrow))
			{ }
			
			else{ }
				
				}
			


}
else{
$newrow="insert into project_register values ('$name','$id','$eventname')";
			if ($connect->query($newrow))
			{
				echo "successfully done!";
				
			}
			else
				echo "not connected";
				echo $connect->error;
}
$connect->close();
