<!DOCTYPE html>
<html>
<title>home page</title>
	<style>
	.hr{
		color:white;
		border-bottom: 3px solid rgb(245, 243, 243);
	}
	</style>
<head>
<meta charset="UTF-8">
<link href="1.css" rel="stylesheet" type="text/css"  media="all" />
<body>

		<img class='bg' src='bg.jpg' alt='background'>
		<h1 >Infirmary Superintendence</h1>
		<hr class="hr">

			<div class="form">
				<a href="adminlog.php"><img class="img1" src="admin2.png"></a>
				<a href="doctorlog.php"><img class="img2" src="doctor.png"></a></br>
				<a href="plog.php"><img class="img3" src="patient.png"></a>

</body>
</html>
s
