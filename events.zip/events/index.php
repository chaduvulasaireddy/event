<!DOCTYPE html>
<html>
<title>home page</title>
	<style>
	.hr{
		color:white;
		border-bottom: 3px solid rgb(245, 243, 243);
	}
	</style>
<head>
<meta charset="UTF-8">
<link href="home.css" rel="stylesheet" type="text/css"  media="all" />
<body>
	<div class="banner-area">
		<header>
			<div class="wrapper">
			<div class="logo">
				<a href="">EVENT MANAGEMENT</a></div>
				<nav>
				<a href="Mini/HTML/login.html">LOGIN</a>
				<a href="Mini/HTML/sign_up.html">SIGN UP</a>
                                <a href="Mini/HTML/adminlogin.html">ADMIN</a>
                                <a href="Mini/HTML/search.html">ABOUT</a></nav>

				
			</div>
		</header>
	
</body>
</html>

