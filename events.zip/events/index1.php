<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>EVENT MANAGMENT</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	
</head>
<body>
	<div class="banner-area">
		<header>
			<div class="wrapper">
			<div class="logo">
				<a href="">EVENT MANAGEMENT</a></div>
				<nav>
				<a href="Mini/HTML/login.html">LOGIN</a>
				<a href="Mini/HTML/sign_up.html">SIGN UP</a>
                                <a href="Mini/HTML/adminlogin.html">ADMIN</a>
                                <a href="Mini/HTML/search.html">ABOUT</a></nav>
				
			</div>
		</header>
	
</body>
</html>
