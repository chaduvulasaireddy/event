<!DOCTYPE html>
<head>
    <title> search</title>
    <style>
    body{
        background-image:url('med.jpg');
    }
    table,th,td{
        border:2px solid black;
        width:1100px;
        background-color:lightblue;
    }
    .btn{
        width:20%;
        height:5%;
        font-size:22px;
        padding:0px;
    }
    .container{
    width:1150px;
	height:460px;
	background:rgba(0,0,0,0.3);
	color:black;
	top:50%;
	margin-left:-500px;
	position:absolute;
	transform:translate(50%,-50%);
	padding:20px 30px;
	
    }
    .btn1{
        background-color: DodgerBlue;
        float:right;
  border: none;
  color: white;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
    
    }
    .b a{
	font-size:15px;
	color:#fff;
}
.b a:hover{
	color:#39dc79;
}
</style>
</head>
<body>
<a href='index1.php'> <button  class="btn1" ><img src="1.png" alt="Snow" height=25px width=25px> Home</button></a>
   </div>
    <div class="container">
        <form action="" method="POST">
            <input type="text" name="username" class="btn"placeholder="Enter doc username"/>
            <input type="submit" name="search" class="btn"value="SEARCH BY ID"/>
        </form>
        <table>
                <tr>
                    <th>Event Name</th>
                    <th>Event Details</th>
                    s
               </tr> <br>
               <?php
               $connection = mysqli_connect("localhost","root","") ;
               $db=mysqli_select_db($connection,'login1');
               if(isset($_POST['search']))
               {
                   $username = $_POST['username'];
                   $query = "SELECT * FROM eventTable where username='$username'";

                   $query_run = mysqli_query($connection,$query);
                   while($row = mysqli_fetch_array($query_run))
                   {
                       ?>
                       <tr>
                           <td> <?php echo $row['Event Name']; ?> </td>
                           <td> <?php echo $row['Event Details']; ?> </td>
                          
                        </tr>
                        <?php

                      
                        
                   }
               } 
               ?>  
    </div>    
</table>
<div class="b">
<a href="retrive1.php"><h1>Go back</h1></a>
            </div>
</body>

</html>
