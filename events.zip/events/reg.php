<!DOCTYPE html>
<html>
<title>Register</title>
<head>
<link rel="stylesheet" href="Project.css">
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<style type=text/css>
	@import "https://use.fontawesome.com/releases/v5.5.0/css/all.css";
</style>
</head>
<body>
<form action="register.php" method="post">
<table>
<tr>
	<td colspan=2 align="center"><b>REGISTER<br><br></b></td>
</tr>
<tr>
	<td><i class="fas fa-user-circle"></i>Name:</td>
	<td><input type="text" name="name" placeholder="Enter your name"  pattern="[a-zA-Z]+" required/>
</tr>
<tr>
	<td><i class="fa fa-id-card">Id:</td>
	<td><input type="text" name="id" placeholder="Enter SignUpyour id" required/>
</tr>
<tr>
	<td><i class="fas fa-user-circle"></i>Event Name:</td>
	<td><input type="text" name="event_name" placeholder="Enter your name"  pattern="[a-zA-Z]+" required/>
</tr>
<tr>
	<td colspan=2><input type="submit" class="bt" name="signin" value="Register"/></td>
</tr>
</table>
<?php
$conn=mysqli_connect("localhost","root","","Project") or die (mysql_error());

if(isset($_POST["signin"]))
{
	$name= $_POST['name'];
	$id= $_POST['id'];
	$EventName= $_POST['event_name'];
	
	if(!empty($Name) && !empty($Id) && !empty($EventName)){
		if($password==$cpass){
			$create="CREATE TABLE IF NOT EXIST project_register ( name VARCHAR(50) NOT NULL , id VARCHAR(20) NOT NULL ,event_name VARCHAR(50) NOT NULL )";
			mysqli_query($conn,$create);
			$s= "select * from project_register where name ='$name'";
			$result=mysqli_query($conn,$s);
			if(mysqli_num_rows($result) == 1){
				echo '<script>alert("Already Registered!!")</script>';
			}
			else{
				$insert="insert into project_register (name,id,event_name) values('$name','$id','$EventName')";
			if(mysqli_query($conn,$insert)){
				echo '<script>alert("Registered Successfully")</script>';
			}
			else{
				echo "Error is:" . mysqli_error($conn);
			}
		}
		}
		else{
			echo '<script>alert("Passwords are not matching.Please enter correct password")</script>';
		}
	}
}
?>
