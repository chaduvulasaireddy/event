<!DOCTYPE html>
<head>
    <title> search</title>
    <style>
    body{
        color:white;
    }
	.a{
		color:white;
		border-bottom: 3px solid rgb(245, 243, 243);
	}

    
    .btn{
        background-color: DodgerBlue;
        float:right;
  border: none;
  color: white;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
    
    }
    .btn2{
        margin-top:3%;
        margin-right:-8%;
        background-color: DodgerBlue;
        float:right;
  border: none;
  color: white;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
    
    }
    .container1{
    width:1150px;
	height:440px;
	background:rgba(0,0,0,0.1);
	color:black;
	top:50%;
	margin-left:-500px;
	position:absolute;
	transform:translate(50%,-50%);
	padding:10px 30px;
	
    }
    .btn1{
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}
.bg{
	top:0px;
	left:0px;
	width:100%;
	height:100%;
	position: absolute;
	z-index: -1;
	background-size: cover;
	background-attachment: fixed;
}
</style>
<script>
    function m(){
        document.getElementById("d")
        .style.display="inline";
    }
    </script>
</head>
<body>
    <div class='d'>
<h1 align='center'>Event Management</h1> <hr class='a'>&nbsp;
 <a href='index.php'> <button  class="btn" ><img src="1.png" alt="Snow" height=25px width=25px> Home</button></a>

</div>
<a href='adminlo.php'> <button  class="btn2" >GOBACK</button></a>
 <img class='bg' src='b.jpg' alt='background'>  

<a href="docreg.php"><button class='btn1'>Add Event</button></a>
<a href="rd.php"><button class='btn1'>GET Event DETAILS</button></a>
</body>

</html>
