<?php
$set=mysqli_connect("localhost","root","","login1");
//include("setting.php");
$Name=$_POST['Name'];
$Id=$_POST['Id'];
$Emailid=$_POST['Email id'];
$Phonenumber=$_POST['Phone number'];
$Password=$_POST['Password'];
$ConfirmPassword=$_POST['Confirm Password'];
if($Name==NULL ||$Id ==NULL ||$Emailid==NULL  || $Phonenumber==NULL ||  $Password==NULL || $_POST['Password']==NULL||$_POST['Confirm Password]==NULL)
{
}
else
{
	$sql=mysqli_query($set,"INSERT INTO student(Name,Id,Emailid,Phonenumber,Password,ConfirmPassword) VALUES('$Name','$Id','$Emailid','$Phonenumber','$Password','$ConfirmPassword')");
	if($sql)
	{
		$msg="Successfully Registered";
	}
	else
	{
		$msg="User Already Exists";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html  charset=utf-8" />
<title>Registration Page</title>
<link href="reg1.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="signbox">
<h1>Doctor Registration</h1>
<br />
<br />
<form method="post" action="">
<table>
<tr>
	<td><i class="fas fa-user-circle"></i>Name:</td>
	<td><input type="text" name="name" placeholder="Enter your name"  pattern="[a-zA-Z]+" required/>
</tr>
<tr>
	<td><i class="fa fa-id-card">Id:</td>
	<td><input type="text" name="id" placeholder="Enter your id" required/>
</tr>
<tr>
	<td><i class="fas fa-envelope">Email id:</td>
	<td><input type="email" name="email" placeholder="Enter your email id"/>
</tr>
<tr>
	<td><i class="fas fa-phone">Phone number:</td>
	<td><input type="num" name="ph_no" placeholder="Enter your Phone no" pattern="^[789]\d{9}$" required/>
</tr>
<tr>
	<td><i class="fas fa-lock">Password:</td>
	<td><input type="password" name="password" placeholder="Enter your Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password is not strong" required/>
</tr>
<tr>
	<td><i class="fas fa-key">Confirm Password:</td>
	<td><input type="password" name="cpassword" placeholder="Re-enter your Password" required/>
</tr>
<tr>
	<td colspan=2><input type="submit" class="bt" name="signin" value="Register"/></td>
</tr>
</table>
<a href="retrive1.php" class="link">Go Back</a>
<br />
<br />

</div>
</div>
</body>
</html>
